//
//  RoutineContainerView.swift
//  BluesMaker
//
//  Created by Kangiriyanka The Single Leaf on 2025/02/12.
//

import SwiftUI
import SwiftData

struct RoutineContainerView: View {
    
    @Environment(\.modelContext)  var modelContext
    @State private var showingUploadRoutineSheet: Bool = false
    @State private var showingConfirmation: Bool = false
    @State private var searchText: String = ""
    @State private var routinePendingDeletion: Routine? = nil
    @Environment(\.dismiss) private var dismiss
    @Query(sort: \Routine.title) var routines: [Routine]
    @Environment(\.colorScheme) var colorScheme
    @AppStorage("gridMode") private var gridMode: GridMode = .list
    @State private var selectedRoutineID: UUID? = nil



    
    var filteredRoutines: [Routine] {
        if searchText.isEmpty {
            return routines
        }
        return routines.filter { $0.title.localizedCaseInsensitiveContains(searchText) }
    }
    
     enum GridMode: String, CaseIterable {
            case list, grid2, grid3
            
            var columns: [GridItem] {
                switch self {
                case .list: return [GridItem(.flexible())]
                case .grid2: return [GridItem(.adaptive(minimum: 140), spacing: 15)]
                case .grid3: return [GridItem(.adaptive(minimum: 100), spacing: 15)]
                }
            }
            
            var icon: String {
                switch self {
                case .list: return "rectangle.grid.1x2"
                case .grid2: return "square.grid.2x2"
                case .grid3: return "square.grid.3x2"
                }
            }
            
            mutating func cycle() {
                let all = Self.allCases
                self = all[(all.firstIndex(of: self)! + 1) % all.count]
            }
        }
  
    
    var body: some View {
        
        NavigationStack {
            
            
            
            VStack {
                
                HStack(spacing: 10) {
                    Spacer()
              
                    CustomSearchBar(
                        text: $searchText,
                        placeholder: "Search routines"
                    )
                    
                    .contentShape(Rectangle())
                    
                    
                    
                    HStack {
                        
                        viewModeButton
                        addRoutineButton
                    }
                    
                    Spacer()
                    
                }
               
                .frame(maxWidth: .infinity)
               
                .sheet(isPresented: $showingUploadRoutineSheet) {
                
                        UploadRoutineView()
                            .background(noSinBackgroundGradient.opacity(0.9))
                    
                }
                
                
                
                
                
                
                Group {
                    if filteredRoutines.isEmpty {
                        
                        ContentUnavailableView {
                            Label("No routines found", systemImage: "music.quarternote.3")
                        } description: {
                            
                            VStack(alignment: .leading, spacing: 1) {
                                Button("Create your first routine") {
                                    showingUploadRoutineSheet.toggle()
                                }
                                .padding()
                                .buttonStyle(ReviewButtonStyle())
                                .contentShape(Rectangle())
                                
                                HStack(spacing: 4) {
                                    Text("Create more later by tapping the ") +
                                    Text(Image(systemName: "plus.circle"))
                                   +
                                    Text(" in the actions above.")
                                        .foregroundStyle(.secondary)
                                        
                                    
                                }
                                .padding(.horizontal, 11)
                                .multilineTextAlignment(.leading)
                                .offset(y: -3)
                                .frame(maxWidth: .infinity)
                                .font(.subheadline)
                            
                                
                            
                        }
                        
                       
                        }
                      
                        
                        
                        
                        
                        
                        
                        
                    }
                    else {
                        
                        // Animation Problems
                        // Don't use LazyVStack and LazyVGrid, just use one.
                        
                            ScrollView(showsIndicators: false) {
                                
                               
                                gridView(for: gridMode)
                                   
                                       
    
                                
                            }
                      
                          
                          
                         
                            .contentMargins(.horizontal, 10, for: .scrollContent)
                            .contentMargins(.bottom, 50, for: .scrollContent)
                            .contentMargins(.top, 10, for: .scrollContent)
                        
                 
                        
                        
                       
                    }
                     
                        

                        
                    
                    
                }
               
         
               
                .padding()
               
 
                .navigationTitle("Routines")
                .ignoresSafeArea(.keyboard)
                .navigationBarTitleDisplayMode(.inline)
              
                
                
                
                
                
            }
            
            
    
            .background(
                backgroundGradient
            )

            
            
            
            
        }
        
        
        
    }
        
        @ViewBuilder
        private func gridView(for mode: GridMode) -> some View {
            ScrollView(showsIndicators: false) {
                LazyVGrid(columns: mode.columns, spacing: 10) {
                    ForEach(filteredRoutines) { routine in
                        NavigationLink(
                            destination: RoutineView(routine: routine)
                                .navigationBarBackButtonHidden(true)
                        ) {
                            if mode == .list {
                                RoutineCardView(routine: routine)
                            } else {
                                CompactRoutineCard(
                                    routine: routine,
                                    gridMode: mode.rawValue
                                )
                            }
                        }
                        .buttonStyle(NavButtonStyle())
                    }
                }
            }
        }
        private var addRoutineButton: some View {
            Button {
                
                showingUploadRoutineSheet.toggle()
            } label: {
                Image(systemName: "plus.circle")
                
                
                
            }
           
            .buttonStyle(PressableButtonStyle())
            .contentShape(Rectangle())
            
            
        }
        
        
        private var viewModeButton: some View {
            Button {
                withAnimation(.organicFastBounce) {
                           gridMode.cycle()
                       }
                   
                
                
                    

            } label: {
                Image(systemName: gridMode.icon)
                .frame(width: 10)
            }
            .buttonStyle(PressableButtonStyle())
            .contentShape(Rectangle())
        }
        
        
        
        
        
        
        
        
    }
    
    
    
    
    struct CompactRoutineCard: View {
        let routine: Routine
        let gridMode: String
        
        var fontSize: CGFloat {
            switch gridMode {
            case "grid2":
                return 16
            default:
                return 14
            }
        }
        
        var lineLimit: Int {
            switch gridMode {
            case "grid2":
                return 2
            default:
                return 3
            }
            
        }
        
        var height: CGFloat {
            switch gridMode {
            case "grid2":
                return 120
            default:
                return 130
            }
            
        }
        
        var body: some View {
            VStack(spacing: 8) {
                ZStack {
                    Circle()
                        .fill(Color.accent.opacity(0.15))
                        .frame(width: gridMode == "rectangle.grid.1x2" ? 40: 30, height: gridMode == "grid2" ? 40: 30)
                    
                    Image(systemName: "music.note")
                        .foregroundStyle(.accent.opacity(0.7))
                        .font(.system(size: 16, weight: .semibold))
                }
                .frame(width: 40, height: 40)
                
                
                Text(routine.title)
                    .font(.system(size: fontSize))
                    .fontWeight(.semibold)
                    .lineLimit(lineLimit)
                    .fixedSize(horizontal: false, vertical: true)
                    .multilineTextAlignment(.center)
                    .foregroundStyle(Color.mainText)
                    .truncationMode(.tail)
            
                    
            }
            .padding()
            .frame(maxWidth: .infinity, maxHeight: height, alignment: .top)
            .frame(height: height,  alignment: .top)
            .background(routineCardBackground)
           
            
            .customBorderStyle()
           
            
        }
    }
    
    
    struct RoutineCardView: View {
        
    
        let routine: Routine
        
        var body: some View {
            
            
            
            
            HStack(spacing: 12) {
                
                ZStack {
                    Circle()
                        .fill(Color.accent.opacity(0.15))
                        .frame(width: 40, height: 40)
                    
                    Image(systemName: "music.note")
                        .foregroundStyle(.accent.opacity(0.7))
                        .font(.system(size: 20, weight: .semibold))
                    
                    
                    
                }
                
                VStack(alignment: .leading, spacing: 10) {
                    Text(routine.title)
                        .font(.headline.weight(.semibold))
                        .foregroundStyle(Color.mainText)
                    
                    Text(routine.routineDescription)
                        .font(.footnote)
                        .foregroundStyle(Color.mainText.opacity(0.6))
                        .lineLimit(2)
                        .offset(y: -8)
                    
                    
                }
                .frame(height: 50)
                
                Spacer()
                
                
                
                
            }
            
            .padding(16)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(routineCardBackground)
            .customBorderStyle()
            
            
        }
    }
    
    
    
    
    #Preview {
        let container = Routine.preview
        
        RoutineContainerView()
            .modelContainer(container)
    }
    
    #Preview {
        
        RoutineContainerView()
        
        
    }
    
    







